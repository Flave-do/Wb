var blue = '#2196f3';
var blue_l5 = '#f2f9fe';
var blue_l2 = '#79bff8';
var blue_d1 = '#0c87eb';
var blue_d5 = '#074b83';

var yellow = '#ffeb3b';
var green = '#4caf50';
var red = '#f44336';
var white = '#fff';
var black = '#000';

zeu.Settings.fps = 60;

var heartbeatConfig = {
    fontColor: white,
    lineColor: green
};
var heartbeat1 = new zeu.Heartbeat(document.getElementById('heartbeat-1'), heartbeatConfig);
var heartbeat2 = new zeu.Heartbeat(document.getElementById('heartbeat-2'), heartbeatConfig);
setInterval(function () {
    heartbeat1.beat();
}, 1000);

setInterval(function () {
    heartbeat2.beat();
}, 1500);

var digitalClock = new zeu.DigitalClcok(
    document.getElementById('digital-clock'),
    {
        dashColor: black,
        numberColor: blue_d1,
        barWidth: 8,
        barHeight: 30,
        space: 8
    }
);
digitalClock.tick();

var doubleCircleConfig1 = {
    isDot: false,
    outer: {
        color: blue_d5,
        radius: 90,
        speed: 0.7

    },
    inner: {
        color: blue_l2,
        radius: 70,
        speed: 0.5
    },
    fontColor: green,
    text: 'NORMAL'
};
var doubleCircle1 = new zeu.DoubleCircle(document.getElementById('double-circle-1'), doubleCircleConfig1);
var doubleCircle2 = new zeu.DoubleCircle(document.getElementById('double-circle-2'), doubleCircleConfig1);

var doubleCircleConfig2 = {
    isDot: true,
    outer: {
        color: blue_d5,
        radius: 90,
        speed: 0.7

    },
    inner: {
        color: blue_l2,
        radius: 80,
        speed: 0.5
    },
    fontColor: green,
    text: 'RUNNING'
};
var doubleCircle3 = new zeu.DoubleCircle(document.getElementById('double-circle-3'), doubleCircleConfig2);
var doubleCircle4 = new zeu.DoubleCircle(document.getElementById('double-circle-4'), doubleCircleConfig2);


var serverGrid = document.getElementById('server-grid-panel');
var servers = ['V', 'W', 'X', 'Y', 'Z'];
var serverTexts = [];
for (var i = 0; i < servers.length; i++) {
    createServerGrid(servers[i]);
}
var clear = document.createElement('div');
clear.style.cssText = 'clear: both;';
serverGrid.appendChild(clear);

function createServerGrid(v) {
    for (var i = 1; i <= 5; i++) {
        var p = document.createElement('div');
        p.innerHTML = v + i;
        p.id = 'server-' + v + i;
        p.className = 'server-grid';
        serverGrid.appendChild(p);

        var blinkText = new zeu.BlinkText(document.getElementById(p.id))
        blinkText.blinkCss = 'color: white; background-color: ' + red + ';';
        serverTexts.push(blinkText);
    }
}

setInterval(function () {
    for (var i = 0; i < serverTexts.length; i++) {
        var status = getRandomInt(0, 2);
        if (status === 0) {
            serverTexts[i].blinkCss = 'color: white; background-color: ' + red + ';';
            serverTexts[i].blink();
        } else if (status === 1) {
            serverTexts[i].blinkCss = 'color: white; background-color: ' + blue_d5 + ';';
            serverTexts[i].blink();
        } else {
            serverTexts[i].unblink();
        }
    }
}, 10000);

var volumenMeterConfig = {
    lineColor: blue_d5,
    fontColor: white,
    fillColor: blue_l2,
    lineWidth: 3
};
var volumeMeter1 = new zeu.VolumeMeter(document.getElementById('volume-meter-1'), volumenMeterConfig);
var volumeMeter2 = new zeu.VolumeMeter(document.getElementById('volume-meter-2'), volumenMeterConfig);
var volumeMeter3 = new zeu.VolumeMeter(document.getElementById('volume-meter-3'), volumenMeterConfig);
var volumeMeter4 = new zeu.VolumeMeter(document.getElementById('volume-meter-4'), volumenMeterConfig);
var volumeMeter5 = new zeu.VolumeMeter(document.getElementById('volume-meter-5'), volumenMeterConfig);
var volumeMeter6 = new zeu.VolumeMeter(document.getElementById('volume-meter-6'), volumenMeterConfig);

setInterval(function () {
    volumeMeter1.value = getRandomInt(0, 100);
    volumeMeter2.value = getRandomInt(0, 100);
    volumeMeter3.value = getRandomInt(0, 100);
    volumeMeter4.value = getRandomInt(0, 100);
    volumeMeter5.value = getRandomInt(0, 100);
    volumeMeter6.value = getRandomInt(0, 100);
}, 1000);

var roundFanConfig = {fanColor: blue, centerColor: black};
var roundFan1 = new zeu.RoundFan(document.getElementById('round-fan-1'), roundFanConfig);
var roundFan2 = new zeu.RoundFan(document.getElementById('round-fan-2'), roundFanConfig);
var roundFan3 = new zeu.RoundFan(document.getElementById('round-fan-3'), roundFanConfig);
var roundFan4 = new zeu.RoundFan(document.getElementById('round-fan-4'), roundFanConfig);
roundFan1.speed = getRandomInt(1, 5);
roundFan2.speed = getRandomInt(1, 5)
roundFan3.speed = getRandomInt(1, 5)
roundFan4.speed = getRandomInt(1, 5)
roundFan1.on();
roundFan2.on();
roundFan3.on();
roundFan4.on();

var fanSpeed1 = document.getElementById('fan-speed-1');
var fanSpeed2 = document.getElementById('fan-speed-2');
var fanSpeed3 = document.getElementById('fan-speed-3');
var fanSpeed4 = document.getElementById('fan-speed-4');
fanSpeed1.innerHTML = roundFan1.speed * 5;
fanSpeed2.innerHTML = roundFan2.speed * 5;
fanSpeed3.innerHTML = roundFan3.speed * 5;
fanSpeed4.innerHTML = roundFan4.speed * 5;

var messageQueueConfig = {barColor: blue_l2, barWidth: 60};
var messageQueue1 = new zeu.MessageQueue(document.getElementById('message-queue-1'), messageQueueConfig);
var messageQueue2 = new zeu.MessageQueue(document.getElementById('message-queue-2'), messageQueueConfig);
var messageQueue3 = new zeu.MessageQueue(document.getElementById('message-queue-3'), messageQueueConfig);
var messageQueue4 = new zeu.MessageQueue(document.getElementById('message-queue-4'), messageQueueConfig);
var messageQueue5 = new zeu.MessageQueue(document.getElementById('message-queue-5'), messageQueueConfig);
var messageQueue6 = new zeu.MessageQueue(document.getElementById('message-queue-6'), messageQueueConfig);

var mqSize1 = document.getElementById('queue-size-1');
var mqSize2 = document.getElementById('queue-size-2');
var mqSize3 = document.getElementById('queue-size-3');
var mqSize4 = document.getElementById('queue-size-4');
var mqSize5 = document.getElementById('queue-size-5');
var mqSize6 = document.getElementById('queue-size-6');

setInterval(function () {
    if (isPush()) {
        messageQueue1.push();
    }
    if (isPush()) {
        messageQueue2.push();
    }
    if (isPush()) {
        messageQueue3.push();
    }
    if (isPush()) {
        messageQueue4.push();
    }
    if (isPush()) {
        messageQueue5.push();
    }
    if (isPush()) {
        messageQueue6.push();
    }

    mqSize1.innerHTML = messageQueue1.queueSize;
    mqSize2.innerHTML = messageQueue2.queueSize;
    mqSize3.innerHTML = messageQueue3.queueSize;
    mqSize4.innerHTML = messageQueue4.queueSize;
    mqSize5.innerHTML = messageQueue5.queueSize;
    mqSize6.innerHTML = messageQueue6.queueSize;
}, 500);

function isPush() {
    return getRandomInt(0, 1) === 0 ? true : false;
}

setInterval(function () {
    messageQueue1.pop();
    messageQueue2.pop();
    messageQueue3.pop();
    messageQueue4.pop();
    messageQueue5.pop();
    messageQueue6.pop();
}, 1000);


var scrollPanel = new zeu.ScrollPanel(document.getElementById('scroll-panel'));
setInterval(function () {
    var message = document.createElement('div');
    var color = getSrollColor();
    message.style.cssText = 'margin: 5px;';
    var time = document.createElement('div');
    time.innerHTML = getCurrentTime();
    time.style.cssText = 'width: 100px; text-align: center; padding: 5px; float: left; color: white; background-color: ' + color + ';';
    var value = document.createElement('div');
    value.innerHTML = 'msg-' + getRandomInt(100, 900) + ' incident ' + getRandomInt(0, 100);
    value.style.cssText = 'width: 250px; padding: 5px; float: left; margin-left: 10px; border-bottom: 1px solid ' + color + ';';
    var clear = document.createElement('div');
    clear.style.cssText = 'clear: both;';
    message.appendChild(time);
    message.appendChild(value);
    message.appendChild(clear);
    scrollPanel.push(message);
}, 500);

function appendZero(n) {
    if (n < 10) {
        return '0' + n;
    }
    return n;
}

function getCurrentTime() {
    var now = new Date();
    var time = appendZero(now.getHours()) + ':' + appendZero(now.getMinutes()) + ':' + appendZero(now.getSeconds());
    return time;
}

setInterval(function () {
    scrollPanel.pop();
}, 800);

function getSrollColor() {
    var c = getRandomInt(0, 3);
    if (c == 0) {
        return blue;
    }
    else if (c == 1) {
        return blue_l2;
    }
    else if (c == 2) {
        return blue_d1;
    }
    return blue_d5;
}

var barMeterConfig1 = {barColor: blue_d1};
var barMeter1 = new zeu.BarMeter(document.getElementById('bar-meter-1'), barMeterConfig1);
var barMeter2 = new zeu.BarMeter(document.getElementById('bar-meter-2'), barMeterConfig1);
var barMeter3 = new zeu.BarMeter(document.getElementById('bar-meter-3'), barMeterConfig1);
var barMeter4 = new zeu.BarMeter(document.getElementById('bar-meter-4'), barMeterConfig1);

var barMeterConfig2 = {barColor: blue_d1};
var barMeter5 = new zeu.BarMeter(document.getElementById('bar-meter-5'), barMeterConfig2);
var barMeter6 = new zeu.BarMeter(document.getElementById('bar-meter-6'), barMeterConfig2);
var barMeter7 = new zeu.BarMeter(document.getElementById('bar-meter-7'), barMeterConfig2);
var barMeter8 = new zeu.BarMeter(document.getElementById('bar-meter-8'), barMeterConfig2);

var stoargePct1 = document.getElementById('capacity-pct-1');
var stoargePct2 = document.getElementById('capacity-pct-2');
var stoargePct3 = document.getElementById('capacity-pct-3');
var stoargePct4 = document.getElementById('capacity-pct-4');
var stoargePct5 = document.getElementById('capacity-pct-5');
var stoargePct6 = document.getElementById('capacity-pct-6');
var stoargePct7 = document.getElementById('capacity-pct-7');
var stoargePct8 = document.getElementById('capacity-pct-8');

setInterval(function () {
    barMeter1.value = getRandomInt(10, 90);
    barMeter2.value = getRandomInt(10, 90);
    barMeter3.value = getRandomInt(10, 90);
    barMeter4.value = getRandomInt(10, 90);
    barMeter5.value = getRandomInt(10, 90);
    barMeter6.value = getRandomInt(10, 90);
    barMeter7.value = getRandomInt(10, 90);
    barMeter8.value = getRandomInt(10, 90);

    stoargePct1.innerHTML = barMeter1.valuePct;
    stoargePct2.innerHTML = barMeter2.valuePct;
    stoargePct3.innerHTML = barMeter3.valuePct;
    stoargePct4.innerHTML = barMeter4.valuePct;
    stoargePct5.innerHTML = barMeter5.valuePct;
    stoargePct6.innerHTML = barMeter6.valuePct;
    stoargePct7.innerHTML = barMeter7.valuePct;
    stoargePct8.innerHTML = barMeter8.valuePct;

}, 5000);


var warningDialog = new zeu.WarningDialog();
warningDialog.reason = 'PLEASE CHECK YOUR SERVER!';

setInterval(function () {
    warningDialog.blink();
    setTimeout(function () {
        warningDialog.unblink();
    }, 6500);
}, 20000);


function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}