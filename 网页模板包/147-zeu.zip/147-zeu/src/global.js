
let GLOBAL = {
  requestAnimationFrameArray: []
};

export { GLOBAL };
